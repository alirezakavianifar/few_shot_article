import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from sklearn.manifold import TSNE
from tqdm.notebook import tqdm
from models.dekae import DEKAEModel

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# ── Section 17: Visualization Suite ──────────────────────────────────────────
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import networkx as nx
from sklearn.manifold import TSNE

sns.set_theme(style="whitegrid", font_scale=1.1)
SAVE_DIR = RESULTS_DIR / "figures"
SAVE_DIR.mkdir(exist_ok=True)


# ── Plot 1: Graph Topology per GNN Layer ─────────────────────────────────────

def plot_topology(A: torch.Tensor, labels: torch.Tensor, title: str = "",
                  save_path=None):
    """Visualise an episode graph coloured by class label."""
    N = A.size(0)
    A_np = (A > 0.01).float().cpu().numpy()
    G    = nx.from_numpy_array(A_np)

    label_list = labels.cpu().tolist()
    cmap = plt.colormaps.get_cmap("tab10")
    colors = [cmap(l / max(max(label_list), 1)) for l in label_list]

    fig, ax = plt.subplots(figsize=(6, 5))
    pos = nx.spring_layout(G, seed=42)
    nx.draw_networkx(G, pos, node_color=colors,
                     with_labels=False, node_size=120,
                     edge_color="#aaa", width=0.6, ax=ax)
    ax.set_title(title)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120)
    plt.show()


# ── Plot 2: Degree Distribution Histogram ─────────────────────────────────────

def plot_degree_distribution(A: torch.Tensor, title: str = "", save_path=None):
    A_no_diag = A.clone(); A_no_diag.fill_diagonal_(0)
    degrees = (A_no_diag > 0).float().sum(dim=1).cpu().numpy()
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.hist(degrees, bins=range(int(degrees.max()) + 2),
            color="steelblue", edgecolor="white")
    ax.set_xlabel("Node Degree")
    ax.set_ylabel("Count")
    ax.set_title(title or "Degree Distribution")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120)
    plt.show()


# ── Plot 3: Graph Density Curve over Training ─────────────────────────────────

def plot_density_curve(history: list, save_path=None):
    epochs    = [h["epoch"] for h in history]
    densities = [h.get("graph_density", 0) for h in history]
    fig, ax   = plt.subplots(figsize=(6, 3))
    ax.plot(epochs, densities, color="coral", linewidth=2)
    ax.axhline(0.5, ls="--", color="red", alpha=0.6, label="Collapse threshold (0.5)")
    ax.axhspan(0.10, 0.15, alpha=0.08, color="green", label="Target density range (0.10–0.15)")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Graph Density")
    ax.set_title("Graph Density over Training (monitor for collapse)")
    ax.legend()
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120)
    plt.show()


# ── Plot 3b: Intra/Inter Edge Ratio over Training (NEW) ──────────────────────

def plot_edge_ratio_curve(history: list, save_path=None):
    """
    Plot intra-class vs inter-class edge ratios over training.
    Expected: intra_edge_ratio should INCREASE over training as the model
    learns to preferentially connect same-class nodes via the edge correction
    loss. Flat or decreasing intra ratio = edge loss not engaging.
    """
    epochs = [h["epoch"] for h in history if "intra_edge_ratio" in h]
    if not epochs:
        print("No intra_edge_ratio data in history — re-run training with updated code.")
        return
    intra  = [h["intra_edge_ratio"] for h in history if "intra_edge_ratio" in h]
    inter  = [h["inter_edge_ratio"] for h in history if "inter_edge_ratio" in h]

    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.plot(epochs, intra, color="#2ecc71", linewidth=2, label="Intra-class edge ratio")
    ax.plot(epochs, inter, color="#e74c3c", linewidth=2, label="Inter-class edge ratio",
            linestyle="--")
    ax.axhline(1.0 / 5, ls=":", color="gray", alpha=0.7,
               label="Random baseline (1/n_way = 0.20)")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Edge Ratio (support-support edges)")
    ax.set_title("Intra/Inter Edge Ratio over Training\n"
                 "(Rising intra ratio = edge loss building class-consistent topology)")
    ax.legend(fontsize=9)
    ax.set_ylim(0, 1)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120)
    plt.show()


# ── Plot 4: t-SNE Before / After Dynamic Topology ────────────────────────────

def plot_tsne(H_before: torch.Tensor, H_after: torch.Tensor,
              labels: torch.Tensor, save_path=None):
    H_all  = torch.cat([H_before, H_after], dim=0).cpu().detach().numpy()
    labels_np = labels.cpu().numpy()
    tsne   = TSNE(n_components=2, perplexity=15, random_state=42)
    emb    = tsne.fit_transform(H_all)
    N      = H_before.size(0)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, title, start, end in zip(
            axes,
            ["Before (H⁰)", "After Dynamic Topology (Hᴸ)"],
            [0, N], [N, 2 * N]):
        sc = ax.scatter(emb[start:end, 0], emb[start:end, 1],
                        c=labels_np, cmap="tab10", s=40, alpha=0.8)
        ax.set_title(title); ax.axis("off")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120)
    plt.show()


# ── Plot 5: Node Degree vs. Sample Difficulty ─────────────────────────────────

def plot_degree_vs_difficulty(model: DEKAEModel, episode_fn,
                               n_way: int, k_shot: int, n_query: int,
                               n_episodes: int = 600, save_path=None):
    """
    Bin query nodes into easy / medium / hard tertiles by margin difficulty
    d_i = s1(i) - s2(i)  (smaller margin = harder sample).
    Show median node degree per bin with 95% CI error bars.
    """
    model.eval()
    margin_diffs, degrees = [], []

    with torch.no_grad():
        for _ in tqdm(range(n_episodes), desc="Difficulty analysis"):
            s_imgs, s_lbl, q_imgs, q_lbl = episode_fn(n_way, k_shot, n_query)
            s_imgs = s_imgs.to(DEVICE); s_lbl = s_lbl.to(DEVICE)
            q_imgs = q_imgs.to(DEVICE)

            logits, _, mets = model(s_imgs, s_lbl, q_imgs)

            sorted_logits, _ = logits.sort(dim=1, descending=True)
            margin = (sorted_logits[:, 0] - sorted_logits[:, 1]).cpu().numpy()
            margin_diffs.extend(margin.tolist())

            avg_d = mets.get("avg_degree", 0)
            degrees.extend([avg_d] * logits.size(0))

    margin_arr  = np.array(margin_diffs)
    degree_arr  = np.array(degrees)

    tertile1, tertile2 = np.percentile(margin_arr, [33, 66])
    bins = {"Hard\n(low margin)"  : degree_arr[margin_arr <= tertile1],
            "Medium"              : degree_arr[(margin_arr > tertile1) & (margin_arr <= tertile2)],
            "Easy\n(high margin)" : degree_arr[margin_arr > tertile2]}

    labels_plot  = list(bins.keys())
    means  = [np.median(v) for v in bins.values()]
    cis    = [1.96 * np.std(v) / max(np.sqrt(len(v)), 1) for v in bins.values()]

    fig, ax = plt.subplots(figsize=(5, 4))
    ax.bar(labels_plot, means, yerr=cis, color=["#e74c3c", "#f39c12", "#2ecc71"],
           capsize=6, edgecolor="white")
    ax.set_ylabel("Average Node Degree")
    ax.set_title("Node Degree vs. Sample Difficulty\n(Hard samples → more neighbours)")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120)
    plt.show()


# ── Plot 6: Adjacency Heatmap — Static k-NN vs. Learned Dynamic ──────────────

def plot_adjacency_heatmap(A_dynamic: torch.Tensor, A_static: torch.Tensor,
                            labels: torch.Tensor, save_path=None):
    """
    Side-by-side heatmap comparing the static k-NN adjacency to the
    learned dynamic adjacency for the same episode.

    Nodes are sorted by class label so intra-class block structure becomes
    visually apparent.  A well-trained DEKAE model should show stronger
    block-diagonal structure in A_dynamic vs. A_static.

    Plan reference: §6.5 visualisation item 6.

    Parameters
    ----------
    A_dynamic : (N, N) float tensor — learned dynamic adjacency A'(L)
    A_static  : (N, N) float tensor — static k-NN adjacency A_init
    labels    : (N,) long tensor    — node class indices (for reordering)
    save_path : optional file path to save the figure
    """
    try:
        import seaborn as sns
    except ImportError:
        print("seaborn not available — install with: pip install seaborn")
        return

    N = A_dynamic.size(0)
    sort_idx   = torch.argsort(labels).cpu().numpy()
    A_dyn_np   = A_dynamic.cpu().detach().numpy()[sort_idx][:, sort_idx]
    A_stat_np  = A_static.cpu().detach().numpy()[sort_idx][:, sort_idx]
    labels_np  = labels.cpu().numpy()[sort_idx]

    # Build tick positions at class boundaries
    unique, counts = np.unique(labels_np, return_counts=True)
    boundaries = np.cumsum(counts)[:-1] - 0.5

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, mat, title in zip(
            axes,
            [A_stat_np, A_dyn_np],
            ["Static k-NN Adjacency A_init", "Learned Dynamic Adjacency A'(L)"]):
        sns.heatmap(mat, ax=ax, cmap="Blues", vmin=0, vmax=1,
                    xticklabels=False, yticklabels=False,
                    cbar_kws={"shrink": 0.8})
        # Overlay class boundary lines
        for b in boundaries:
            ax.axhline(y=b, color="red", linewidth=0.8, linestyle="--", alpha=0.7)
            ax.axvline(x=b, color="red", linewidth=0.8, linestyle="--", alpha=0.7)
        ax.set_title(title, fontsize=11)
        ax.set_xlabel(f"N={N} nodes (sorted by class)")

    fig.suptitle("Adjacency Comparison: Static vs. Dynamic\n"
                 "(Block-diagonal = class-consistent topology; red lines = class boundaries)",
                 fontsize=11)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=120, bbox_inches="tight")
    plt.show()


# ── Demo: run all plots on the toy model ─────────────────────────────────────

# Plot 1 — episode topology (coloured by class)
_labels_demo = torch.cat([torch.full((4,), c) for c in range(5)]).to(DEVICE)
plot_topology(_A_dyn, _labels_demo, title="Episode Topology (Layer 3)",
              save_path=str(SAVE_DIR / "topology_layer3.png"))

# Plot 2 — degree distribution
plot_degree_distribution(_A_dyn, "Degree Distribution (DEKAE)",
                         save_path=str(SAVE_DIR / "degree_dist.png"))

# Plots 3/3b/4/5 require training history & real data — run after train()
print("\nPlots 3/3b/4/5/6 require training history & real data — run after train().")
print("After training, call:")
print("  plot_density_curve(train_history)")
print("  plot_edge_ratio_curve(train_history)   ← NEW: monitors edge-loss effectiveness")
print("  plot_tsne(H_before, H_after, labels)")
print("  plot_degree_vs_difficulty(eval_model, test_sampler, n_way=5, k_shot=1, n_query=15)")
print("  plot_adjacency_heatmap(A_dyn, A_static, labels) ← plan §6.5 item 6")
