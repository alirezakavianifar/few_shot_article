
class DEKAEModel(nn.Module):
    """
    Dynamic Edge-driven topology for Episodic few-shot learning (DEKAE).

    Architecture per GNN layer
    --------------------------
    1. EdgeIncidenceModule      : X, A(l) → E(l), src, dst
    2. DynamicTopologyModule    : H(l), E(l) → A'(l), sparsity_loss
    3a. EdgeToNodeProjection    : X' = A_edge @ E @ W'          [use_case2=True  ← DEFAULT]
    3b. EdgeAwareKnowledgeFilter: X' = σ(g(E)) · A' @ H        [use_case2=False ← ablation]
    4. Skip connection          : H(l+1) ← H_new + H(0)

    Post-GNN Cross-Set Refinement
    -----------------------------
    5. LatentMediatorTransformer (LMT)  [if use_lmt=True]

    Parameters
    ----------
    embed_dim        : backbone output dimension
    n_gnn_layers     : number of dynamic GNN layers (default 3)
    rank             : rank for low-rank bilinear scorer
    sparsity_mode    : 'l1' | 'topk' | 'laplacian' | 'none'
    use_dynamic      : if False, fall back to static k-NN (FSAKE / ablation A1)
    use_edge_proj    : if True, activate Section 8 edge-aware node update
                       (A2 vs A3/A4 ablation switch)
    use_case2        : if True (default), use EdgeToNodeProjection (X' = A_edge E W')
                       if False, use EdgeAwareKnowledgeFilter (Case 1, ablation A3)
    use_lmt          : if True, apply LatentMediatorTransformer after GNN layers
    n_mediators      : number of learnable mediator tokens (m << N_q, N_s)
    lmt_layers       : number of gather-distribute cycles in LMT
    lmt_init_strategy: mediator token init — 'learned'|'fixed'|'zero'  (plan §5.8 H4)
    lmt_phases       : phase activation   — 'both'|'gather_only'|'distribute_only' (H5)
    edge_loss_mode   : edge supervision level — plan §5.9 Group I ablation
        'all'          — edge loss at every GNN layer, equal weight (I2, default)
        'penultimate'  — edge loss only at the last GNN layer (I1)
        'decaying'     — edge loss at all layers, weight = 1/(L-l) decaying (I3)
    adj_residual     : blend A' with static k-NN to prevent density collapse
    knn_k            : k for static k-NN fallback
    """

    def __init__(self, embed_dim: int = 128, n_gnn_layers: int = 3,
                 rank: int = 16, sparsity_mode: str = "l1",
                 lambda_sparse: float = 0.01, lambda_edge: float = 0.5,
                 topk_k: int = 5, n_way: int = 5, use_dynamic: bool = True,
                 use_edge_proj: bool = True, use_case2: bool = True,
                 edge_dropout: float = 0.1,
                 use_lmt: bool = True, n_mediators: int = 8,
                 lmt_layers: int = 3, lmt_heads: int = 4, lmt_dropout: float = 0.1,
                 lmt_init_strategy: str = "learned", lmt_phases: str = "both",
                 edge_loss_mode: str = "all",
                 adj_residual: float = 0.15):
        super().__init__()
        self.embed_dim        = embed_dim
        self.n_gnn_layers     = n_gnn_layers
        self.n_way            = n_way
        self.use_dynamic      = use_dynamic
        self.use_edge_proj    = use_edge_proj
        self.use_case2        = use_case2
        self.use_lmt          = use_lmt
        self.edge_loss_mode   = edge_loss_mode
        self.adj_residual     = adj_residual   # anti-collapse: blend A' with k-NN
        self.knn_k            = topk_k
        self.lambda_edge      = lambda_edge

        self.backbone = Conv4(embed_dim=embed_dim)

        # Edge incidence modules (shared across both cases)
        self.edge_modules = nn.ModuleList([
            EdgeIncidenceModule(embed_dim, embed_dim, hidden=64)
            for _ in range(n_gnn_layers)
        ])
        # Dynamic topology modules
        self.dynamic_modules = nn.ModuleList([
            DynamicTopologyModule(embed_dim, rank, embed_dim,
                                  sparsity_mode, topk_k, lambda_sparse,
                                  edge_dropout)
            for _ in range(n_gnn_layers)
        ])

        # ── Case 2: EdgeToNodeProjection  (default — the stronger novelty) ────
        # X' = A_edge @ E @ W'   nodes updated from EDGE VECTORS
        self.e2n_modules = nn.ModuleList([
            EdgeToNodeProjection(embed_dim, embed_dim)
            for _ in range(n_gnn_layers)
        ])

        # ── Case 1: EdgeAwareKnowledgeFilter  (ablation A3, use_case2=False) ──
        # X' = σ(g(E)) · A' @ H   classic node aggregation, gated by edge agg.
        self.kf_modules = nn.ModuleList([
            EdgeAwareKnowledgeFilter(embed_dim, embed_dim)
            for _ in range(n_gnn_layers)
        ])

        # ── Latent Mediator Transformer (optional) ────────────────────────────
        if use_lmt:
            self.lmt = LatentMediatorTransformer(
                embed_dim      = embed_dim,
                n_mediators    = n_mediators,
                n_layers       = lmt_layers,
                n_heads        = lmt_heads,
                dropout        = lmt_dropout,
                init_strategy  = lmt_init_strategy,   # H4 ablation
                phases         = lmt_phases,           # H5 ablation
            )
        else:
            self.lmt = None

        self.classifier = nn.Linear(embed_dim, n_way)

    # ── Ablation toggle helpers ───────────────────────────────────────────────
    def set_use_dynamic(self, flag: bool):
        self.use_dynamic = flag

    def set_use_edge_proj(self, flag: bool):
        """False → ablation A2 (dynamic rewiring only, no edge-aware update)."""
        self.use_edge_proj = flag

    def set_use_case2(self, flag: bool):
        """True  → Case 2  X' = A_edge @ E @ W'  (full novelty, ablation A4)
           False → Case 1  X' = σ(g(E)) · A' @ H (edge-gated node agg, A3)."""
        self.use_case2 = flag

    def set_use_lmt(self, flag: bool):
        self.use_lmt = flag

    # ── Forward ───────────────────────────────────────────────────────────────
    def forward(self, imgs_support: torch.Tensor, labels_support: torch.Tensor,
                imgs_query: torch.Tensor, lambda_edge_scale: float = 1.0,
                labels_query: torch.Tensor = None):
        """
        imgs_support      : (N_s, 3, 84, 84)
        labels_support    : (N_s,)
        imgs_query        : (N_q, 3, 84, 84)
        lambda_edge_scale : curriculum multiplier [0, 1] for edge loss
        labels_query      : (N_q,) optional — passed at train time for
                            intra_edge_ratio diagnostic (NOT used in any loss).
                            Required to get meaningful intra/inter ratio for
                            1-shot where support-only ratio is always 0.

        Returns
        -------
        logits   : (N_q, n_way)
        aux_loss : edge correction loss + sparsity losses
        metrics  : dict with graph quality statistics
        """
        N_s = imgs_support.size(0)
        N_q = imgs_query.size(0)

        # ── 1. Encode all nodes ───────────────────────────────────────────────
        all_imgs = torch.cat([imgs_support, imgs_query], dim=0)    # (N, ...)
        H0       = self.backbone(all_imgs)                          # (N, d)

        # Support mask — query labels never used in any loss term
        support_mask = torch.zeros(N_s + N_q, dtype=torch.bool, device=H0.device)
        support_mask[:N_s] = True

        H = H0
        total_sparsity_loss = torch.tensor(0.0, device=H0.device)
        total_edge_loss     = torch.tensor(0.0, device=H0.device)
        layer_stability     = []
        intra_edge_ratio    = 0.0
        inter_edge_ratio    = 0.0

        for l in range(self.n_gnn_layers):
            # ── 2. Initial adjacency ──────────────────────────────────────────
            A_init = build_knn_adjacency(H, k=self.knn_k)

            # ── 3. Edge features  E = B^T X W ────────────────────────────────
            E, src, dst = self.edge_modules[l](H, A_init)

            if self.use_dynamic:
                # ── 4. Dynamic topology A' ────────────────────────────────────
                A_prime, sp_loss = self.dynamic_modules[l](H, E, src, dst)

                # ── Anti-collapse residual blend (Risk: density → 0) ──────────
                # The optimizer can zero all edges to minimise edge+sparsity loss.
                # Blending with the k-NN baseline guarantees minimum connectivity.
                # adj_residual=0.15 means at least 15% of k-NN structure survives.
                if self.adj_residual > 0:
                    A_prime = (1.0 - self.adj_residual) * A_prime \
                              + self.adj_residual * A_init

                # Divide by n_gnn_layers to avoid 3× sparsity amplification
                total_sparsity_loss = total_sparsity_loss + sp_loss / self.n_gnn_layers

                # ── 5. Edge correction loss (support-support only) ────────────
                labels_full = torch.full((N_s + N_q,), -1,
                                         dtype=torch.long, device=H.device)
                labels_full[:N_s] = labels_support
                e_loss_l = edge_correction_loss(E, src, dst, labels_full,
                                                support_mask)

                # Group I: multi-level edge supervision (plan §5.9)
                # 'all' / I2      — equal weight at every layer (default)
                # 'penultimate' / I1 — only final GNN layer
                # 'decaying' / I3 — weight decreases with layer index l
                if self.edge_loss_mode == "penultimate":
                    if l == self.n_gnn_layers - 1:
                        total_edge_loss = total_edge_loss + e_loss_l * lambda_edge_scale
                elif self.edge_loss_mode == "decaying":
                    # weight = 1 / (L - l), higher weight for later layers
                    decay_w = 1.0 / max(self.n_gnn_layers - l, 1)
                    total_edge_loss = total_edge_loss + e_loss_l * lambda_edge_scale * decay_w
                else:  # "all" (default, I2 — equal weight)
                    total_edge_loss = total_edge_loss + e_loss_l * lambda_edge_scale

                # ── Intra/inter ratio diagnostics (last layer only) ───────────
                # Use ALL nodes (support + query) when labels_query is provided;
                # for 1-shot, support-only is always 0 (1 node per class, no
                # two support nodes can share a class label in 1-shot setting).
                if l == self.n_gnn_layers - 1:
                    with torch.no_grad():
                        if labels_query is not None:
                            labels_diag = torch.cat([labels_support, labels_query])
                        else:
                            labels_diag = labels_full  # query positions = -1
                        # only count edges where both endpoints have known labels
                        valid_src  = labels_diag[src] >= 0
                        valid_dst  = labels_diag[dst] >= 0
                        valid_mask = valid_src & valid_dst
                        if valid_mask.sum() > 0:
                            v_src = src[valid_mask]; v_dst = dst[valid_mask]
                            same = (labels_diag[v_src] == labels_diag[v_dst]).float()
                            intra_edge_ratio = same.mean().item()
                            inter_edge_ratio = 1.0 - intra_edge_ratio
            else:
                A_prime = A_init          # static fallback (warm-up / ablation A1)

            # ── 6. Node update: Case 2 (default) or Case 1 (ablation) ─────────
            if self.use_edge_proj:
                if self.use_case2:
                    # ★ Case 2: X' = A_edge @ E @ W'  ← the stronger novelty
                    #   Nodes updated from EDGE FEATURE VECTORS, not node features
                    _, H_new = self.e2n_modules[l](H, E, src, dst)
                else:
                    # Case 1 ablation (A3): edge-gated node aggregation
                    _, H_new = self.kf_modules[l](H, E, src, dst, A_prime)
            else:
                # A2 ablation: dynamic topology, simple message passing only
                H_new = A_prime @ H

            H_new = H_new + H0                                # skip connection

            with torch.no_grad():
                stability = (H_new - H).norm().item()
            layer_stability.append(stability)
            H = H_new

        # ── 7. Split support / query ──────────────────────────────────────────
        H_support = H[:N_s]                                    # (N_s, d)
        H_query   = H[N_s:]                                    # (N_q, d)

        # ── 8. Latent Mediator Transformer (cross-set refinement) ─────────────
        if self.use_lmt and self.lmt is not None:
            H_query, H_support = self.lmt(H_query, H_support)

        # ── 9. Prototype cosine classifier ────────────────────────────────────
        prototypes = torch.zeros(self.n_way, self.embed_dim, device=H.device)
        for c in range(self.n_way):
            mask_c        = labels_support == c
            prototypes[c] = H_support[mask_c].mean(0)

        # NaN-safe normalisation: clamp near-zero vectors before cosine similarity
        # (zero vectors arise when prototype class has collapsed features)
        H_q_norm   = F.normalize(H_query.clamp(-1e4, 1e4),    dim=-1, eps=1e-8)
        proto_norm = F.normalize(prototypes.clamp(-1e4, 1e4), dim=-1, eps=1e-8)
        logits     = H_q_norm @ proto_norm.t()                 # (N_q, n_way)

        aux_loss = total_edge_loss * self.lambda_edge + total_sparsity_loss

        metrics = graph_metrics(A_prime)
        metrics["layer_stability"]  = layer_stability
        metrics["intra_edge_ratio"] = intra_edge_ratio
        metrics["inter_edge_ratio"] = inter_edge_ratio
        return logits, aux_loss, metrics


